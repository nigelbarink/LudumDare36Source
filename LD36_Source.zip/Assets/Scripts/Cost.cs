﻿using UnityEngine;
using System.Collections;

public class Cost : MonoBehaviour {
	public int	cost = 0;
}
